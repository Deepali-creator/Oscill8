'use strict';

/* API Includes */
var Cart = require('~/cartridge/scripts/models/CartModel');
var PaymentMgr = require('dw/order/PaymentMgr');
var Transaction = require('dw/system/Transaction');
var Logger = require('dw/system/Logger');

/**
 * This is where additional PayPal integration would go. The current implementation simply creates a PaymentInstrument and
 * returns 'success'.
 */

 function paypal(){
    var Token = "null";
    var url = '';
    dw.system.Logger.warn('paypal main');
    var createTransaction = LocalServiceRegistry.createService('paypal-nvp', {
        createRequest: function (svc, args) {
             url = svc.getConfiguration().getCredential().getURL();
            svc.setRequestMethod('POST');
            svc.setURL(url);
            svc.addHeader('Content-Type', 'application/x-www-form-urlencoded');
            var payload = "USER=Stam_helpme_api1.conair.com&" +
                "PWD=6ZS7F2NNZZZYW6GJ&SIGNATURE=AQEHES0Eiay.TjBiRotNn.U6SHwMA9G0e3kTHH4ImCMLF7lwe-FcKm.7&" +
                "METHOD="+callMetod+"&VERSION=78&PAYMENTREQUEST_0_PAYMENTACTION=Authorize&" +
                "PAYMENTREQUEST_0_AMT=70&" +
                "PAYMENTREQUEST_0_CURRENCYCODE=USD&" +
                "cancelUrl=https%3A%2F%2Fexample.com%2Fcancel&" +
                "returnUrl=https%3A%2F%2Fdev02-na-conair.demandware.net%2Fon%2Fdemandware.store%2FSites-us-leandrolimited-Site%2Fdefault%2FXipay-returnBack%3F";
            dw.system.Logger.warn('paypal request' + payload);
            return payload;
        },
        parseResponse: function (svc, output) {

            dw.system.Logger.warn('paypal response' + output.text);
            Token = decodeFormParams(output.text.toString()).TOKEN.toString();
            url=url+Token;
            return output;
        }
    });
    createTransaction.call();
   
   return url;


    // response.setContentType('text');
    // response.getWriter().println(url);
 
    



    //redirectToPaypal(Token);
     
 

   

 }


function Handle(args) {
    dw.system.Logger.warn("##################");
    var url = paypal();
  
    dw.system.Logger.warn(url);
    var cart = Cart.get(args.Basket);
     
    Transaction.wrap(function () {

        cart.removeExistingPaymentInstruments('PayPal');
        cart.createPaymentInstrument('PayPal', cart.getNonGiftCertificateAmount());
        
    });

    return {success: true};
}

/**
 * Authorizes a payment using a credit card. The payment is authorized by using the PAYPAL_EXPRESS processor only
 * and setting the order no as the transaction ID. Customizations may use other processors and custom logic to
 * authorize credit card payment.
 */
function Authorize(args) {
    var orderNo = args.OrderNo;
    var paymentInstrument = args.PaymentInstrument;
    var paymentProcessor = PaymentMgr.getPaymentMethod(paymentInstrument.getPaymentMethod()).getPaymentProcessor();

    Transaction.wrap(function () {
        paymentInstrument.paymentTransaction.transactionID = orderNo;
        paymentInstrument.paymentTransaction.paymentProcessor = paymentProcessor;
    });

    return {authorized: true};
}

/*
 * Module exports
 */

/*
 * Local methods
 */
exports.Handle = Handle;
exports.Authorize = Authorize;
