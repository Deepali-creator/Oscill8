var elements = document.getElementsByClassName("radio");

/*for (var i = 0; i < elements.length; i++) {
    elements[i].addEventListener("click", function scrollTo(params) {
        window.scrollTo({
            top: ((100 * i)),
            behavior: "smooth"
        });
    });
}*/
